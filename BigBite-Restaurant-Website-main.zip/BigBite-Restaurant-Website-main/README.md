BootstrapProject1
# bootstrap-project1---Restaurant Website
![header](https://github.com/Hafsa-Kanwal/Big-Bite/assets/141765204/a7183811-3c4d-434e-8122-3febf23d964f)
![Counter](https://github.com/Hafsa-Kanwal/Big-Bite/assets/141765204/faf1b55c-f47f-4fc9-9497-0545ba914439)
![about](https://github.com/Hafsa-Kanwal/Big-Bite/assets/141765204/d0ec2bf9-6754-4509-bc2e-0f93cd331407)
![about2](https://github.com/Hafsa-Kanwal/Big-Bite/assets/141765204/ef5cc809-4f07-4fda-a837-756be8afe5fe)
![about3](https://github.com/Hafsa-Kanwal/Big-Bite/assets/141765204/71120eaa-c4fb-4911-a491-0798cfe289a3)
![Explore more](https://github.com/Hafsa-Kanwal/Big-Bite/assets/141765204/d75d4d13-cdf9-405c-bdab-a5ef9294418f)
![Reviews](https://github.com/Hafsa-Kanwal/Big-Bite/assets/141765204/8acc6888-7679-467f-a653-e14621e7289e)
![Testimonial1](https://github.com/Hafsa-Kanwal/Big-Bite/assets/141765204/afe81c24-7ae5-4c13-99b9-dd38b45e6451)
![testimonial2](https://github.com/Hafsa-Kanwal/Big-Bite/assets/141765204/0b1bfc01-464c-4e41-88da-42547a8688ff)
![form](https://github.com/Hafsa-Kanwal/Big-Bite/assets/141765204/0678d70f-469b-4b21-a02d-3a5c8f358e31)
![footer](https://github.com/Hafsa-Kanwal/Big-Bite/assets/141765204/9a9facce-90e9-4919-8c32-b866c73811dd)





